"""
KerasHub ↔ LangChain Bridge
============================
Custom wrapper that makes KerasHub models (Gemma 2, Llama 3.1) compatible
with LangChain's BaseChatModel interface, enabling use inside LangGraph agents.

This is one of the novel contributions of the project — no existing library
provides this integration.

Usage:
    from foundation.llm_wrapper import KerasHubChatModel
    llm = KerasHubChatModel(config=CONFIG.llm)
    response = llm.invoke([HumanMessage(content="Hello")])
"""

from __future__ import annotations

import json
import logging
from typing import Any, Iterator, List, Optional

from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
)
from langchain_core.outputs import ChatGeneration, ChatResult

import sys
sys.path.append("..")
from config.settings import LLMConfig, CONFIG

logger = logging.getLogger(__name__)


# ── Prompt Formatters ─────────────────────────────────────────────────────────
# Each model family has its own control token format.

def _format_gemma(messages: List[BaseMessage]) -> str:
    """Format messages using Gemma 2 control tokens."""
    parts = []
    for msg in messages:
        if isinstance(msg, SystemMessage):
            # Gemma 2 doesn't have a system role — prepend to first user turn
            parts.append(f"<start_of_turn>user\n[System Instructions]\n{msg.content}\n")
        elif isinstance(msg, HumanMessage):
            # Avoid double user tag if system was prepended
            if parts and parts[-1].startswith("<start_of_turn>user\n[System"):
                parts[-1] += f"\n{msg.content}<end_of_turn>\n"
            else:
                parts.append(f"<start_of_turn>user\n{msg.content}<end_of_turn>\n")
        elif isinstance(msg, AIMessage):
            parts.append(f"<start_of_turn>model\n{msg.content}<end_of_turn>\n")
    # Open the model turn for generation
    parts.append("<start_of_turn>model\n")
    return "".join(parts)


def _format_llama(messages: List[BaseMessage]) -> str:
    """Format messages using Llama 3.1 control tokens."""
    parts = ["<|begin_of_text|>"]
    for msg in messages:
        if isinstance(msg, SystemMessage):
            parts.append(
                f"<|start_header_id|>system<|end_header_id|>\n\n"
                f"{msg.content}<|eot_id|>"
            )
        elif isinstance(msg, HumanMessage):
            parts.append(
                f"<|start_header_id|>user<|end_header_id|>\n\n"
                f"{msg.content}<|eot_id|>"
            )
        elif isinstance(msg, AIMessage):
            parts.append(
                f"<|start_header_id|>assistant<|end_header_id|>\n\n"
                f"{msg.content}<|eot_id|>"
            )
    parts.append("<|start_header_id|>assistant<|end_header_id|>\n\n")
    return "".join(parts)


# Map preset names to formatters
_FORMATTERS = {
    "gemma": _format_gemma,
    "llama": _format_llama,
}

def _get_formatter(preset: str):
    """Select the right prompt formatter based on model preset name."""
    preset_lower = preset.lower()
    for key, fn in _FORMATTERS.items():
        if key in preset_lower:
            return fn
    raise ValueError(
        f"No prompt formatter registered for preset '{preset}'. "
        f"Supported families: {list(_FORMATTERS.keys())}"
    )


# ── KerasHub Chat Model ──────────────────────────────────────────────────────

class KerasHubChatModel(BaseChatModel):
    """
    LangChain-compatible chat model backed by a KerasHub CausalLM.

    Handles:
    1. Prompt Construction — converts LangChain messages to model-specific
       control token format.
    2. Inference — triggers KerasHub generate() with configured sampling.
    3. Output Parsing — strips the prompt echo, extracts generated text.
    """

    # Pydantic fields (LangChain requires these to be class-level)
    config: LLMConfig = None
    model: Any = None           # keras_hub.models.CausalLM (set at init)
    _formatter: Any = None

    class Config:
        arbitrary_types_allowed = True

    def __init__(self, config: Optional[LLMConfig] = None, **kwargs):
        super().__init__(**kwargs)
        self.config = config or CONFIG.llm
        self._formatter = _get_formatter(self.config.preset)
        self._load_model()

    def _load_model(self):
        """Load the KerasHub model with configured precision."""
        try:
            import os
            os.environ["KERAS_BACKEND"] = self.config.backend

            import keras_hub

            logger.info(f"Loading KerasHub model: {self.config.preset} "
                        f"(dtype={self.config.dtype})")
            self.model = keras_hub.models.CausalLM.from_preset(
                self.config.preset,
                dtype=self.config.dtype,
            )
            logger.info("Model loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load primary model: {e}")
            if self.config.fallback_preset:
                logger.info(f"Attempting fallback: {self.config.fallback_preset}")
                self._formatter = _get_formatter(self.config.fallback_preset)
                import keras_hub
                self.model = keras_hub.models.CausalLM.from_preset(
                    self.config.fallback_preset,
                    dtype=self.config.dtype,
                )
            else:
                raise

    # ── LangChain Interface ───────────────────────────────────────────────

    @property
    def _llm_type(self) -> str:
        return "kerashub-chat"

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs,
    ) -> ChatResult:
        """Core generation method called by LangChain."""

        # 1. Format prompt
        prompt = self._formatter(messages)

        # 2. Run inference
        raw_output = self.model.generate(
            prompt,
            max_length=len(prompt) + self.config.max_new_tokens,
        )

        # 3. Strip prompt echo — KerasHub returns prompt + generation
        generated_text = raw_output
        if isinstance(raw_output, str) and raw_output.startswith(prompt):
            generated_text = raw_output[len(prompt):]

        # 4. Clean up trailing control tokens
        for token in ["<end_of_turn>", "<|eot_id|>", "<|end_of_text|>"]:
            generated_text = generated_text.split(token)[0]

        generated_text = generated_text.strip()

        return ChatResult(
            generations=[
                ChatGeneration(message=AIMessage(content=generated_text))
            ]
        )

    # ── Convenience ───────────────────────────────────────────────────────

    def invoke_and_parse_json(
        self, messages: List[BaseMessage], **kwargs
    ) -> dict:
        """Generate and parse a JSON response. Useful for grader/router."""
        result = self.invoke(messages, **kwargs)
        text = result.content.strip()
        # Handle markdown code fences
        if text.startswith("```"):
            text = text.split("```")[1]
            if text.startswith("json"):
                text = text[4:]
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            logger.warning(f"JSON parse failed, raw output: {text[:200]}")
            return {"error": "parse_failed", "raw": text}
