"""
Evaluation Framework
====================
Test suite, metrics, and LLM-judge for evaluating the multi-agent system.
Covers: routing accuracy, retrieval precision, task completion, and
self-correction effectiveness.

Usage:
    from evaluation.metrics import Evaluator
    evaluator = Evaluator(workflow=workflow)
    results = evaluator.run_full_evaluation()
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from langchain_core.messages import HumanMessage

logger = logging.getLogger(__name__)


# ── Test Suite ────────────────────────────────────────────────────────────────

# 150 test queries: 50 per domain
# Each entry: (query, expected_domain, difficulty, description)

INDUSTRIAL_TEST_QUERIES = [
    ("My S7-1200 PLC is showing fault code F0003, what does it mean?", "industrial", "easy", "Direct fault code lookup"),
    ("The VFD on pump station 3 is tripping on overcurrent every morning", "industrial", "medium", "Intermittent fault diagnosis"),
    ("How do I configure PROFINET communication between two Siemens PLCs?", "industrial", "medium", "Configuration procedure"),
    ("What are the recommended PM intervals for Allen-Bradley servo drives?", "industrial", "easy", "Maintenance schedule"),
    ("Our SCADA system is losing connection to RTUs intermittently", "industrial", "hard", "Network troubleshooting"),
    ("Explain the difference between SIL 2 and SIL 3 safety requirements", "industrial", "medium", "Safety standards"),
    ("Motor bearing temperature is trending upward over the last month", "industrial", "medium", "Predictive maintenance"),
    ("How to reset a PowerFlex 525 drive after an F0063 fault?", "industrial", "easy", "Fault recovery procedure"),
    ("What causes ground fault alarms on a 480V distribution panel?", "industrial", "medium", "Electrical troubleshooting"),
    ("Best practices for PLC program backup and version control", "industrial", "easy", "Best practices"),
    # ... Add 40 more for full test suite
]

RECIPE_TEST_QUERIES = [
    ("What can I substitute for eggs in a chocolate cake recipe?", "recipe", "easy", "Common substitution"),
    ("I have chicken, rice, and bell peppers. What can I make?", "recipe", "medium", "Ingredient-based search"),
    ("How do I make a proper roux for gumbo?", "recipe", "easy", "Technique question"),
    ("What's the difference between baking soda and baking powder?", "recipe", "easy", "Ingredient knowledge"),
    ("Give me a gluten-free pasta recipe with under 500 calories", "recipe", "medium", "Dietary constraint search"),
    ("How long should I rest a steak after grilling?", "recipe", "easy", "Technique timing"),
    ("What's a good dairy-free alternative to heavy cream in soup?", "recipe", "medium", "Dietary substitution"),
    ("How do I properly temper chocolate for dipping?", "recipe", "hard", "Advanced technique"),
    ("What spices pair well with lamb?", "recipe", "easy", "Flavor pairing"),
    ("Can you give me a quick weeknight dinner recipe for 4 people?", "recipe", "medium", "Recommendation"),
    # ... Add 40 more for full test suite
]

SCIENTIFIC_TEST_QUERIES = [
    ("Summarize recent papers on transformer attention mechanisms", "scientific", "medium", "Topic synthesis"),
    ("What are the key findings from the latest RLHF research?", "scientific", "medium", "Current research"),
    ("Find papers about graph neural networks for drug discovery", "scientific", "easy", "Topic search"),
    ("What is the state of the art in protein structure prediction?", "scientific", "hard", "SOTA review"),
    ("Compare self-supervised vs supervised pretraining for NLP", "scientific", "hard", "Comparative analysis"),
    ("What datasets are commonly used for named entity recognition?", "scientific", "easy", "Resource query"),
    ("Explain the mixture of experts architecture in LLMs", "scientific", "medium", "Concept explanation"),
    ("Recent advances in federated learning for medical imaging", "scientific", "medium", "Domain-specific search"),
    ("What are the limitations of current RAG approaches?", "scientific", "medium", "Limitations analysis"),
    ("Find papers on energy-efficient training of large language models", "scientific", "easy", "Topic search"),
    # ... Add 40 more for full test suite
]

# Ambiguous/edge-case queries for routing stress testing
EDGE_CASE_QUERIES = [
    ("What temperature should I cook chicken to avoid equipment failure?", "clarify", "hard", "Ambiguous cross-domain"),
    ("How do I calibrate my oven thermometer?", "clarify", "medium", "Could be recipe or industrial"),
    ("What is the recipe for disaster recovery?", "clarify", "hard", "Metaphorical language"),
    ("Tell me about mixing processes in chemical plants", "industrial", "medium", "Industrial — not recipe mixing"),
    ("How does a neural network learn?", "scientific", "easy", "Clear scientific"),
]

ALL_TEST_QUERIES = (
    INDUSTRIAL_TEST_QUERIES
    + RECIPE_TEST_QUERIES
    + SCIENTIFIC_TEST_QUERIES
    + EDGE_CASE_QUERIES
)


# ── Metrics ───────────────────────────────────────────────────────────────────

@dataclass
class EvaluationResult:
    """Aggregated evaluation results."""
    routing_accuracy: float = 0.0
    routing_by_domain: Dict[str, float] = field(default_factory=dict)
    task_completion_rate: float = 0.0
    avg_latency_seconds: float = 0.0
    self_correction_rate: float = 0.0
    per_query_results: List[Dict] = field(default_factory=list)


class Evaluator:
    """
    Full evaluation suite for the multi-agent system.
    """

    def __init__(self, workflow, llm=None):
        self.workflow = workflow
        self.llm = llm  # For LLM-judge scoring

    def evaluate_routing(
        self,
        test_queries: Optional[List] = None,
    ) -> Dict:
        """
        Evaluate routing accuracy across all test queries.

        Returns accuracy overall and per-domain.
        """
        from orchestration.workflow_graph import run_query

        queries = test_queries or ALL_TEST_QUERIES
        correct = 0
        domain_correct = {}
        domain_total = {}
        results = []

        for query, expected_domain, difficulty, desc in queries:
            start = time.time()
            result = run_query(self.workflow, query)
            latency = time.time() - start

            actual_domain = result.get("domain", "")
            is_correct = actual_domain == expected_domain

            if is_correct:
                correct += 1

            domain_correct[expected_domain] = (
                domain_correct.get(expected_domain, 0) + (1 if is_correct else 0)
            )
            domain_total[expected_domain] = (
                domain_total.get(expected_domain, 0) + 1
            )

            results.append({
                "query": query,
                "expected": expected_domain,
                "actual": actual_domain,
                "correct": is_correct,
                "confidence": result.get("confidence", 0),
                "latency": latency,
                "difficulty": difficulty,
            })

        accuracy = correct / len(queries) if queries else 0.0
        per_domain = {
            d: domain_correct.get(d, 0) / domain_total.get(d, 1)
            for d in domain_total
        }

        return {
            "overall_accuracy": accuracy,
            "per_domain_accuracy": per_domain,
            "total_queries": len(queries),
            "correct": correct,
            "results": results,
        }

    def evaluate_llm_judge(
        self,
        query: str,
        response: str,
        domain: str,
    ) -> Dict:
        """
        Use LLM-as-judge to score a response for quality.

        Scores on: relevance, accuracy, completeness, clarity (each 1-5).
        """
        if not self.llm:
            return {"error": "No LLM provided for judging"}

        prompt = (
            f"You are evaluating an AI assistant's response quality.\n\n"
            f"Domain: {domain}\n"
            f"User Query: {query}\n"
            f"Assistant Response: {response}\n\n"
            f"Score the response on these dimensions (1-5 each):\n"
            f"1. Relevance — Does it address the query?\n"
            f"2. Accuracy — Is the information correct and grounded?\n"
            f"3. Completeness — Does it fully answer the question?\n"
            f"4. Clarity — Is it well-organized and easy to understand?\n\n"
            f"Respond with ONLY valid JSON:\n"
            f'{{"relevance": <1-5>, "accuracy": <1-5>, '
            f'"completeness": <1-5>, "clarity": <1-5>, '
            f'"overall": <1-5>, "feedback": "<brief explanation>"}}'
        )

        try:
            result = self.llm.invoke_and_parse_json(
                [HumanMessage(content=prompt)]
            )
            return result
        except Exception as e:
            return {"error": str(e)}

    def run_full_evaluation(self) -> EvaluationResult:
        """Run the complete evaluation suite."""
        logger.info("Starting full evaluation...")

        routing_results = self.evaluate_routing()

        eval_result = EvaluationResult(
            routing_accuracy=routing_results["overall_accuracy"],
            routing_by_domain=routing_results["per_domain_accuracy"],
            per_query_results=routing_results["results"],
            avg_latency_seconds=(
                sum(r["latency"] for r in routing_results["results"])
                / len(routing_results["results"])
                if routing_results["results"] else 0
            ),
        )

        # Task completion = queries that got a real response (not escalated/clarified)
        completed = sum(
            1 for r in routing_results["results"]
            if r.get("correct")
        )
        eval_result.task_completion_rate = completed / len(routing_results["results"]) if routing_results["results"] else 0

        logger.info(
            f"Evaluation complete. Routing accuracy: {eval_result.routing_accuracy:.2%}"
        )
        return eval_result
