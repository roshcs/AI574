"""
Supervisor Agent
================
Central router that classifies user intent and delegates to specialists.
Implements confidence-based routing with clarification fallback.

Usage:
    from orchestration.supervisor import SupervisorAgent
    supervisor = SupervisorAgent(llm=llm)
    routing = supervisor.route("My PLC is showing fault code F0003")
    # → {"domain": "industrial", "confidence": 0.98, ...}
"""

from __future__ import annotations

import logging
from typing import Dict

from langchain_core.messages import HumanMessage

from config.prompts import SUPERVISOR_SYSTEM_PROMPT
from config.settings import CONFIG

logger = logging.getLogger(__name__)


class SupervisorAgent:
    """
    Supervisor/Router Agent.

    Analyzes user queries and routes to the appropriate specialist agent.
    Uses few-shot prompting and confidence scoring.
    """

    def __init__(self, llm):
        self.llm = llm
        self.threshold = CONFIG.supervisor.routing_confidence_threshold
        self.valid_domains = set(CONFIG.supervisor.domains + ["clarify", "fallback"])

    def route(self, query: str) -> Dict:
        """
        Classify and route a user query.

        Returns:
            {
                "domain": str,         # target domain or "clarify"/"fallback"
                "confidence": float,   # 0.0 - 1.0
                "reasoning": str,      # explanation
            }
        """
        prompt = (
            f"{SUPERVISOR_SYSTEM_PROMPT}\n\n"
            f"User query: \"{query}\"\n\n"
            f"Route this query:"
        )

        try:
            result = self.llm.invoke_and_parse_json(
                [HumanMessage(content=prompt)]
            )

            if "error" in result:
                logger.warning(f"Supervisor parse failed: {result.get('raw', '')[:100]}")
                return self._fallback_routing(query)

            # Validate domain
            domain = result.get("domain", "fallback")
            if domain not in self.valid_domains:
                logger.warning(f"Invalid domain '{domain}', using fallback")
                domain = "fallback"

            confidence = float(result.get("confidence", 0.0))

            # If confidence is below threshold, request clarification
            if confidence < self.threshold and domain not in ("clarify", "fallback"):
                logger.info(
                    f"Low confidence ({confidence:.2f} < {self.threshold}), "
                    f"switching to clarification"
                )
                domain = "clarify"

            routing = {
                "domain": domain,
                "confidence": confidence,
                "reasoning": result.get("reasoning", ""),
            }

            logger.info(
                f"Routed to '{domain}' (confidence={confidence:.2f}): "
                f"{routing['reasoning'][:60]}"
            )
            return routing

        except Exception as e:
            logger.error(f"Supervisor routing failed: {e}")
            return self._fallback_routing(query)

    def generate_clarification(self, query: str, routing: Dict) -> str:
        """Generate a clarification question when routing is ambiguous."""
        prompt = (
            f"The user asked: \"{query}\"\n\n"
            f"This query is ambiguous — it could relate to multiple domains. "
            f"Routing analysis: {routing.get('reasoning', 'unclear intent')}\n\n"
            f"Generate a SHORT, friendly clarification question to determine "
            f"the user's intent. Ask about the specific domain they need help with."
        )

        try:
            result = self.llm.invoke([HumanMessage(content=prompt)])
            return result.content.strip()
        except Exception:
            return (
                "I want to make sure I help you with the right thing. "
                "Could you clarify whether this is about industrial equipment, "
                "cooking/recipes, or scientific research?"
            )

    @staticmethod
    def _fallback_routing(query: str) -> Dict:
        """Fallback when LLM routing fails entirely."""
        return {
            "domain": "fallback",
            "confidence": 0.0,
            "reasoning": "Routing failed — using web search fallback",
        }
